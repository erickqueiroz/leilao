<?php

return [
    'telegram' => [
        'exception_reporting' => [
            'endpoint' => 'https://api.telegram.org/bot',
            'bot' => '1168167624:AAGlqprGbkfx69Hx8aoz29T7JCe17H-J_dg',
            'chat_id' => -1001484194065,
            'env' => 'DEV'
        ]
    ],
];
