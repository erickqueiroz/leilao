<?php

namespace Main\Db\TableGateway;

use Application\Db\TableGateway\CrudTableGateway;

class EmailMintTableGateway extends CrudTableGateway
{
    const TABLE = 'email_mint';
}
