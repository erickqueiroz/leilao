<?php

namespace ApplicationTest\Db\TableGateway;

use Application\Db\TableGateway\CrudTableGateway;

/**
 * Class DumbTableGateway
 * @package ApplicationTest\Db\TableGateway
 *
 * @codeCoverageIgnore
 */
class DumbTableGateway extends CrudTableGateway
{

}
